সুগন্ধি মিষ্টি ওয়েবসাইট — GitHub Pages

ফাইল:
- index.html : ওয়েবসাইটের পেজ
- style.css  : ডিজাইন
- script.js  : কার্ট ও অর্ডার ফর্মের আচরণ

গুরুত্বপূর্ণ:
1) script.js ফাইলে WHATSAPP_NUMBER-এ নিজের WhatsApp নম্বর আন্তর্জাতিক ফরম্যাটে দিন, যেমন 8801XXXXXXXXX (X-এর জায়গায় আসল সংখ্যা)।
2) script.js ফাইলে BKASH_NUMBER-এ নিজের বিকাশ নম্বর দিন।
3) এই সংস্করণে বিকাশের স্বয়ংক্রিয় পেমেন্ট গেটওয়ে নেই; এটি নম্বর দেখায়। স্বয়ংক্রিয় পেমেন্টের জন্য বিকাশ মার্চেন্ট অ্যাকাউন্ট ও অনুমোদিত API/backend দরকার।
4) পণ্য/দাম/ছবি পরিবর্তন এই ব্রাউজারে স্থানীয়ভাবে সেভ হয়; এটি সুরক্ষিত অ্যাডমিন প্যানেল নয়।

GitHub-এ আপলোড:
1) Repository খুলুন > Add file > Upload files
2) ZIP ফাইলটি আগে কম্পিউটারে Extract করুন। এরপর ভেতরের index.html, style.css, script.js এবং README.txt ফাইলগুলো একসঙ্গে টেনে আপলোড করুন।
3) Commit changes চাপুন।
4) Settings > Pages > Build and deployment > Deploy from a branch নির্বাচন করুন।
5) Branch: main এবং Folder: /(root) নির্বাচন করে Save করুন।
6) কিছুক্ষণ পর Settings > Pages-এ প্রকাশিত URL দেখাবে।
